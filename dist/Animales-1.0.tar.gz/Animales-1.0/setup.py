#from setuptools import setup

#__author__ = 'yago'

#setup(name='Animales',
#      version='1.0',
#      description='Proyecto de tienda de animales',
#      author='Yago Perez',
#      author_email='yagoelvago@gmail.com',
#      url='https://www.python.org/sigs/distutils-sig/',
#      packages=['Animales'],
#     )

from distutils.core import setup

setup(name='Animales',
      version='1.0',
      py_modules=['Animales'],
      )